<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Berita</title>
    <link rel="stylesheet" href="/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h3>Berita</h3>
        <button type="button" class="btn btn-success mb-2" data-toggle="modal" data-target="#addModal">Add New</button>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul</th>
                    <th>Kategori</th>
                    <th>Isi</th>
                    <th>dilihat</th>
                    <th>Posting</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1;

                foreach ($berita as $row) : ?>
                    <tr>
                        <td><?= $no ?></td>
                        <td><?= $row->judul; ?></td>
                        <td><?= $row->category_name; ?></td>
                        <td><?= $row->isi; ?></td>
                        <td><?= $row->lihat; ?></td>
                        <td><?= $row->post_date; ?></td>
                        <td>
                            <a href="#" class="btn btn-info btn-sm btn-edit" data-id="<?= $row->post_id; ?>" data-judul="<?= $row->judul; ?>" data-isi="<?= $row->isi; ?>" data-id_kategori="<?= $row->id_kategori; ?>">Edit</a> <a href="#" class="btn btn-danger btn-sm btn-delete" data-toggle="modal" data-target="#deleteModal<?= $row->post_id; ?>">Delete</a>
                        </td>
                    </tr>

                    <!-- Modal Delete -->
                    <form action="/berita/delete/<?= $row->post_id; ?>" method="post">
                        <div class="modal fade" id="deleteModal<?= $row->post_id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Delete Berita</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">

                                        <h4>Are you sure want to delete this Artikel?</h4>

                                    </div>
                                    <div class="modal-footer">
                                        <input type="hidden" name="post_id" value="<?= $row->post_id; ?>">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                                        <button type="submit" class="btn btn-primary">Yes</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- End Modal Delete -->
                <?php
                    $no++;





                endforeach; ?>
            </tbody>
        </table>

    </div>

    <!-- Modal Add -->
    <form action="/berita/save" method="post">
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add berita</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group">
                            <label>judul</label>
                            <input type="text" class="form-control" name="judul" placeholder="judul berita">
                        </div>

                        <div class="form-group">
                            <label>Isi Berita</label>
                            <textarea class="form-control" placeholder="isi berita" name="isi"></textarea>
                        </div>

                        <div class="form-group">
                            <label>Category</label>
                            <select name="kategori" class="form-control">
                                <option value="">-Select-</option>
                                <?php foreach ($category as $row) : ?>
                                    <option value="<?= $row->category_id; ?>"><?= $row->category_name; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <!-- End Modal Add -->

    <!-- Modal Edit -->
    <form action="/berita/update" method="post">
        <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edit Product</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group">
                            <label>Product Name</label>
                            <input type="text" class="form-control judul" name="judul" placeholder="judul">
                        </div>

                        <div class="form-group">
                            <label>Price</label>
                            <textarea class="form-control isi" placeholder="isi berita" name="isi"></textarea>
                        </div>

                        <div class="form-group">
                            <label>Category</label>
                            <select name="id_kategori" class="form-control id_kategori">
                                <option value="">-Select-</option>
                                <?php foreach ($category as $row) : ?>
                                    <option value="<?= $row->category_id; ?>"><?= $row->category_name; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="post_id" class="post_id">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <!-- End Modal Edit -->



    <script src="/js/jquery.min.js"></script>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {

            // get Edit 
            $('.btn-edit').on('click', function() {
                // get data from button edit
                const id = $(this).data('id');
                const judul = $(this).data('judul');
                const isi = $(this).data('isi');
                const id_kategori = $(this).data('id_kategori');
                // Set data to Form Edit
                $('.post_id').val(id);
                $('.judul').val(judul);
                $('.isi').val(isi);
                $('.id_kategori').val(id_kategori).trigger('change');
                // Call Modal Edit
                $('#editModal').modal('show');
            });


        });
    </script>
</body>

</html>