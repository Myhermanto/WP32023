<?php

namespace App\Models;

use CodeIgniter\Model;

class Berita_model extends Model
{
    public function getCategory()
    {
        $builder = $this->db->table('category');
        return $builder->get();
    }

    public function getberita()
    {
        $builder = $this->db->table('post');
        $builder->select('*');
        $builder->join('category', 'category_id = id_kategori', 'left');
        return $builder->get();
    }

    public function saveberita($data)
    {
        $query = $this->db->table('post')->insert($data);
        return $query;
    }

    public function updateberita($data, $id)
    {
        $query = $this->db->table('post')->update($data, array('post_id' => $id));
        return $query;
    }

    public function deleteberita($id)
    {
        $query = $this->db->table('post')->delete(array('post_id' => $id));
        return $query;
    }
}
