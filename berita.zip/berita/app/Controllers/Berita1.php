<?php

namespace App\Controllers;

class Berita1 extends BaseController
{
    public function index()
    {
        return view('welcome_message');
    }
}
