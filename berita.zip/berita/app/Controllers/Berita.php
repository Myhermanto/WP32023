<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Berita_model;

class Berita extends Controller
{
    public function index()
    {
        $model = new Berita_model();
        $data['berita']  = $model->getberita()->getResult();
        $data['category'] = $model->getCategory()->getResult();
        echo view('berita_view', $data);
    }
    public function save()
    {
        $tanggal = date('Y-m-d');
        $model = new Berita_model();
        $data = array(
            'judul'        => $this->request->getPost('judul'),
            'isi'       => $this->request->getPost('isi'),
            'id_kategori' => $this->request->getPost('kategori'),
            'post_date' => $tanggal
        );
        $model->saveberita($data);
        return redirect()->to('/berita');
    }
    public function update()
    {
        $model = new Berita_model();
        $tanggal = date('Y-m-d');
        $id = $this->request->getPost('post_id');
        $data = array(
            'judul'        => $this->request->getPost('judul'),
            'isi'       => $this->request->getPost('isi'),
            'id_kategori' => $this->request->getPost('id_kategori'),
            'post_date' => $tanggal
        );
        $model->updateberita($data, $id);
        return redirect()->to('/berita');
    }
    public function delete()
    {
        $model = new Berita_model();
        $id = $this->request->getPost('post_id');
        $model->deleteberita($id);
        return redirect()->to('/berita');
    }
}
