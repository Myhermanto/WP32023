<!-- end: sidebar -->

<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>


    </header>

    <div class="row">

        <div class="col-md-12 col-lg-12 col-xl-12">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-xl-12">
                    <section class="panel panel-featured-left panel-featured-primary">
                        <div class="panel-body">
                            <div class="widget-summary">

                                <div class="widget-summary-col">
                                    <div class="summary">
                                        <h4 class="title">Selamat Datang Di Administratro - Admin </h4>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </section>
                </div>

            </div>
        </div>
    </div>
</section>
</div>